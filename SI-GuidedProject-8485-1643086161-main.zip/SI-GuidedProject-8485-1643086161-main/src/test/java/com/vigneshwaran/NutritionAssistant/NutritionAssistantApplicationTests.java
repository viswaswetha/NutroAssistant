package com.vigneshwaran.NutritionAssistant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NutritionAssistantApplicationTests {

	@Test
	void contextLoads() {
	}

}
